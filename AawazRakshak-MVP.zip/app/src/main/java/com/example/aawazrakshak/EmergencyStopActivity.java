
package com.example.aawazrakshak;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import androidx.appcompat.app.AppCompatActivity;

public class EmergencyStopActivity extends AppCompatActivity {
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stop);

        tts = new TextToSpeech(this, status -> {
            tts.speak("Emergency activated. Transaction cancelled.",
            TextToSpeech.QUEUE_FLUSH, null, null);
        });
    }
}
