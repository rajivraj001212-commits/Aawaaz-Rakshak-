
package com.example.aawazrakshak;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import androidx.appcompat.app.AppCompatActivity;

public class QrScamActivity extends AppCompatActivity {
    TextToSpeech tts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr);

        tts = new TextToSpeech(this, status -> {
            tts.speak("QR scan karne se paisa jaata hai. PIN mat daaliye.",
            TextToSpeech.QUEUE_FLUSH, null, null);
        });
    }
}
