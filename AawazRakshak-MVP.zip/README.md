
# Aawaz Rakshak – MVP

Simulation-based Android MVP demonstrating protection against
fake voice calls, deepfake videos, and QR-based UPI scams.

This is a demo MVP for hackathon submission.
