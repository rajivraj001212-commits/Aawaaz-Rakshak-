# Aawaaz-Rakshak-
Simulation-based Android MVP to prevent fake voice calls, deepfake videos, and QR-based UPI scams using voice alerts and visual warnings.
